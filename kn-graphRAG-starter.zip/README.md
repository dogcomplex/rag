# kn-graphRAG-starter (Windows + LM Studio)

See setup.ps1 for bootstrap and README in canvas for details.
