import hnswlib, numpy as np, pathlib, json
class HNSWIndex:
    def __init__(self, path: pathlib.Path, dim=768, space='cosine'):
        self.path = path
        self.meta_path = path.with_suffix('.meta.json')
        self.dim = dim
        self.space = space
        self.index = hnswlib.Index(space=space, dim=dim)
        self.inited = False
        self.ids = []
    @classmethod
    def open(cls, cfg, dim=768):
        path = pathlib.Path(cfg["stores"]["vector"]["path"])
        meta = path.with_suffix('.meta.json')
        if path.exists() and meta.exists():
            m = json.loads(meta.read_text())
            dim = m.get("dim", dim)
            obj = cls(path, dim=dim)
            obj.index.load_index(str(path))
            obj.index.set_ef(128)
            obj.inited = True
            obj.ids = m.get("ids", [])
            return obj
        return cls(path, dim=dim)
    def _ensure_init(self, total=10000):
        if not self.inited:
            self.index.init_index(max_elements=total, ef_construction=200, M=16)
            self.index.set_ef(128)
            self.inited = True
    def add(self, keys, vecs: np.ndarray):
        self._ensure_init(max(10000, len(self.ids) + len(keys) + 1000))
        labels = np.arange(len(self.ids), len(self.ids)+len(keys))
        self.index.add_items(vecs, labels)
        self.ids.extend(list(keys))
    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.index.save_index(str(self.path))
        self.meta_path.write_text(json.dumps({"dim": self.dim, "ids": self.ids}))
    def search(self, vecs: np.ndarray, k=10):
        labels, dists = self.index.knn_query(vecs, k=k)
        inv = self.ids
        mapped = [[inv[i] for i in row] for row in labels]
        return mapped, dists